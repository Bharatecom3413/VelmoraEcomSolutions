# Velmora Ecom Solutions – Android app

Premium black-and-gold Android app built with Kotlin and Jetpack Compose for direct APK sharing.

## Customer features
- Home, Amazon / Flipkart / Meesho / e-commerce consulting services
- Service package list (loads active packages managed by the admin; falls back to enquiry-only sample plans)
- Customer enquiry submission to Cloud Firestore
- WhatsApp fallback, phone, email and Jaipur contact details

## Admin features
- Firebase Email/Password sign-in; admin access requires the verified `admin == true` custom claim
- Enquiry inbox with contacted status and delete actions
- Client records: create, read, edit and delete
- Orders/projects: create, read, edit and delete
- Service packages: create, read, edit and delete; active packages are shown to customers
- No public admin registration

## Required setup before a live APK
Firebase credentials and Android build tools are intentionally not included.
1. Open the project in Android Studio.
2. Create a Firebase project and add Android app package `com.velmora.ecomsolutions`.
3. Download `google-services.json` into `app/google-services.json`.
4. Enable Firebase Authentication > Email/Password and create the owner/admin account.
5. Create Cloud Firestore and publish `firestore.rules`.
6. Grant the owner account the custom claim `{ "admin": true }` using a trusted server environment and Firebase Admin SDK. Never grant this from the app.
7. Run Gradle sync, test customer enquiry submission and all admin CRUD flows, then Build > Build Bundle(s) / APK(s) > Build APK(s).

See `FIREBASE_SETUP.md` for the secure Firebase setup details. A Firebase project, config file, admin account and rules deployment are necessary for the live admin/backend features. The source archive is not itself an installable APK.
