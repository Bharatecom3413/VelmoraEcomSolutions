# Firebase setup required before live backend use

This project has Firebase Authentication and Cloud Firestore client integration, but it is not connected to a Firebase project yet. No credentials or secrets are included.

## 1. Create and connect a Firebase project
1. Create a Firebase project in the Firebase console.
2. Add an Android app with package name `com.velmora.ecomsolutions`.
3. Download its `google-services.json` and place it at `app/google-services.json` (same level as `app/build.gradle.kts`). Do not commit this file to a public repository.
4. Enable **Authentication > Sign-in method > Email/Password**.
5. Create your administrator account in Firebase Authentication. Do not add public admin sign-up to the app.

## 2. Grant admin access safely
The app checks the Firebase ID token for the boolean custom claim `admin == true`. A trusted server environment using the Firebase Admin SDK must grant this claim after verifying the account is authorised. Never set custom claims from the Android app or trust a user-editable Firestore field as an admin role.

Example server-side Node.js snippet (run only in a trusted, access-controlled admin environment):

```js
await getAuth().setCustomUserClaims(uid, { admin: true });
```

After the claim is assigned, sign out and sign back in (or refresh the ID token) so the app receives it.

## 3. Publish Firestore rules
Create a Cloud Firestore database and publish the root `firestore.rules` file from this project. These rules allow unauthenticated app visitors to create validated enquiry documents, while only users with the verified `admin` custom claim can read enquiries or manage client/order/package records.

Review the rules against your final operational needs before production. Add App Check, abuse/rate limiting (typically via a trusted callable/API or edge layer), data retention policy, and appropriate privacy notices before public release.

## 4. Suggested data model
- `enquiries/{id}`: name, phone, message, status, createdAt
- `clients/{id}`: name, phone, email, marketplace, notes, createdAt, updatedAt
- `orders/{id}`: clientId, service, packageId, status, startDate, endDate, notes
- `packages/{id}`: name, durationMonths, price, features, active

The current app submits enquiry documents and reads recent enquiries in the admin screen. Client, order and package administration screens are still planned; Firestore rules reserve those collections for admin access.

## 5. Local build
Open the project in Android Studio, add `app/google-services.json`, allow Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The APK output is shown by Android Studio. Test enquiry submission on a real configured Firebase project and verify unauthorised users cannot read enquiries.
