package com.velmora.ecomsolutions

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private val Ink = Color(0xFF0B0B0D)
private val Panel = Color(0xFF171719)
private val Gold = Color(0xFFD6AD55)
private val Muted = Color(0xFFB8B3A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VelmoraApp() }
    }
}

@Composable
fun VelmoraApp() {
    var tab by remember { mutableStateOf("Home") }
    var admin by remember { mutableStateOf(false) }
    var adminEmail by remember { mutableStateOf("") }
    var serviceMessage by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, secondary = Gold, background = Ink, surface = Panel,
        onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Gold) {
                    val tabs = listOf("Home", "Services", "Packages", "Enquiry", "Admin")
                    tabs.forEach { item ->
                        val icon = when (item) {
                            "Home" -> Icons.Default.Home
                            "Services" -> Icons.Default.Storefront
                            "Packages" -> Icons.Default.Work
                            "Enquiry" -> Icons.Default.Message
                            else -> Icons.Default.Lock
                        }
                        NavigationBarItem(
                            selected = tab == item, onClick = { tab = item },
                            icon = { Icon(icon, contentDescription = item) },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                indicatorColor = Color(0xFF3A2E17),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                TopBar()
                when (tab) {
                    "Home" -> HomeScreen({ tab = "Services" }, { tab = "Enquiry" })
                    "Services" -> ServicesScreen { service ->
                        serviceMessage = "I am interested in $service services."
                        tab = "Enquiry"
                    }
                    "Packages" -> PackagesScreen { packageName ->
                        serviceMessage = "Please send details for the $packageName package."
                        tab = "Enquiry"
                    }
                    "Enquiry" -> EnquiryScreen(serviceMessage)
                    else -> AdminGate(
                        isAdmin = admin, email = adminEmail,
                        onSignedIn = { email -> admin = true; adminEmail = email },
                        onSignedOut = { admin = false; adminEmail = ""; tab = "Home" }
                    )
                }
            }
        }
    }
}

@Composable
private fun TopBar() {
    Row(Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Gold, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text("V", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("VELMORA", color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
            Text("ECOM SOLUTIONS", color = Color.White, fontSize = 10.sp, letterSpacing = 2.sp)
        }
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = Gold, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun HomeScreen(onServices: () -> Unit, onEnquiry: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(
                androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF302513), Panel, Ink)),
                RoundedCornerShape(24.dp)).padding(22.dp)) {
                Text("GROW YOUR", color = Muted, letterSpacing = 3.sp, fontSize = 12.sp)
                Text("ONLINE\nBUSINESS.", color = Gold, fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(10.dp))
                Text("Your trusted partner for marketplace growth.", color = Color.White)
                Spacer(Modifier.height(20.dp))
                GoldButton("Explore Our Services", onServices)
            }
        }
        item { SectionTitle("Marketplace solutions") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniFeature("Amazon", "Seller support", Modifier.weight(1f))
                MiniFeature("Flipkart", "Marketplace growth", Modifier.weight(1f))
                MiniFeature("Meesho", "Catalog support", Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("LET'S BUILD YOUR BRAND", color = Gold, fontWeight = FontWeight.Bold)
                    Text("Tell us about your business and our team will get in touch.", color = Muted)
                    Spacer(Modifier.height(12.dp))
                    GoldButton("Send an Enquiry", onEnquiry)
                }
            }
        }
        item { ContactCard() }
    }
}

@Composable
private fun MiniFeature(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Icon(Icons.Default.Storefront, tint = Gold, contentDescription = null)
            Spacer(Modifier.height(8.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ServicesScreen(onSelect: (String) -> Unit) {
    val services = listOf(
        "Amazon" to "Seller account assistance, product listing and marketplace support.",
        "Flipkart" to "Catalog support, product visibility and seller growth assistance.",
        "Meesho" to "Product catalog support and marketplace account assistance.",
        "E-commerce Consulting" to "Guidance to start and grow your online business."
    )
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("Our Services") }
        item { Text("Marketplace solutions designed to help your business grow.", color = Muted) }
        items(services) { (name, desc) ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(name, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(desc, color = Muted)
                    Spacer(Modifier.height(12.dp))
                    GoldButton("Enquire Now") { onSelect(name) }
                }
            }
        }
    }
}

@Composable
private fun PackagesScreen(onChoose: (String) -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var livePackages by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    LaunchedEffect(Unit) {
        try {
            val snap = db.collection("packages").whereEqualTo("active", true).get().await()
            livePackages = snap.documents.mapNotNull { it.data }
        } catch (_: Exception) { livePackages = emptyList() }
    }
    val defaults = listOf(
        Triple("1 Month", "A focused starting plan for your marketplace needs.", ""),
        Triple("2 Months", "Consistent support to improve your store operations.", ""),
        Triple("3 Months", "Extended support for a longer growth journey.", "")
    )
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { SectionTitle("Service Packages") }
        item { Text("Choose a duration and request a customised quotation.", color = Muted) }
        if (livePackages.isEmpty()) {
            items(defaults) { (name, desc, _) ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(name.uppercase(), color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(8.dp)); Text(desc, color = Muted); Spacer(Modifier.height(14.dp))
                        GoldButton("Get Package Details") { onChoose(name) }
                    }
                }
            }
            item { Text("Package prices and exact inclusions are confirmed by Velmora.", color = Muted, fontSize = 12.sp) }
        } else {
            items(livePackages) { item ->
                val name = item["name"]?.toString() ?: "Service Package"
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(name.uppercase(), color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                        Text("₹${item["price"] ?: "Contact us"}", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp)); Text(item["features"]?.toString() ?: "Customised seller support", color = Muted)
                        Spacer(Modifier.height(14.dp)); GoldButton("Get Package Details") { onChoose(name) }
                    }
                }
            }
        }
    }
}

@Composable
private fun EnquiryScreen(prefill: String) {
    val context = LocalContext.current
    val db = remember { FirebaseFirestore.getInstance() }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var message by remember(prefill) { mutableStateOf(prefill) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("Start a Conversation") }
        item { Text("Submit your details to the Velmora team.", color = Muted) }
        item { OutlinedTextField(name, { name = it }, label = { Text("Your name") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item { OutlinedTextField(phone, { phone = it }, label = { Text("Mobile number") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)) }
        item { OutlinedTextField(message, { message = it }, label = { Text("Requirement") }, modifier = Modifier.fillMaxWidth(), minLines = 3) }
        item {
            GoldButton(if (busy) "Submitting…" else "Submit Enquiry") {
                if (name.isBlank() || phone.isBlank() || message.isBlank()) {
                    status = "Please complete all fields."
                } else {
                    busy = true
                    status = ""
                    scope.launch {
                        try {
                            db.collection("enquiries").add(hashMapOf(
                                "name" to name.trim(), "phone" to phone.trim(),
                                "message" to message.trim(), "status" to "new",
                                "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                            )).await()
                            status = "Enquiry submitted successfully."
                            name = ""; phone = ""; message = ""
                        } catch (_: Exception) {
                            status = "Online submission unavailable. You can send the enquiry via WhatsApp."
                        } finally { busy = false }
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = {
                val body = "Velmora enquiry\nName: $name\nPhone: $phone\nRequirement: $message"
                context.startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/917877561704?text=${Uri.encode(body)}")))
            }, modifier = Modifier.fillMaxWidth()) { Text("Continue on WhatsApp", color = Gold) }
        }
        if (status.isNotBlank()) item { Text(status, color = Gold) }
        item { ContactCard() }
    }
}

@Composable
private fun AdminGate(isAdmin: Boolean, email: String, onSignedIn: (String) -> Unit, onSignedOut: () -> Unit) {
    if (isAdmin) AdminDashboard(email, onSignedOut) else AdminLogin(onSignedIn)
}

@Composable
private fun AdminLogin(onSignedIn: (String) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val auth = remember { FirebaseAuth.getInstance() }
    val scope = rememberCoroutineScope()

    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { SectionTitle("Admin Login") }
        item { Text("Authorised Velmora administrators only.", color = Muted) }
        item { OutlinedTextField(email, { email = it }, label = { Text("Admin email") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item { OutlinedTextField(password, { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation()) }
        item {
            GoldButton(if (loading) "Signing in…" else "Secure Sign In") {
                if (email.isBlank() || password.isBlank()) {
                    error = "Enter your email and password."
                } else {
                    loading = true; error = ""
                    scope.launch {
                        try {
                            val result = auth.signInWithEmailAndPassword(email.trim(), password).await()
                            val token = result.user?.getIdToken(true)?.await()
                            val isAdminClaim = token?.claims?.get("admin") == true
                            if (isAdminClaim) onSignedIn(result.user?.email ?: email)
                            else {
                                auth.signOut()
                                error = "This account does not have administrator access."
                            }
                        } catch (_: Exception) {
                            error = "Sign-in failed. Check credentials and Firebase setup."
                        } finally { loading = false }
                    }
                }
            }
        }
        if (error.isNotBlank()) item { Text(error, color = Color(0xFFFF8A80)) }
        item {
            Text("Admin accounts must be created in Firebase Authentication and granted the admin custom claim by a trusted server-side administrator. There is no public admin registration in this app.",
                color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun AdminDashboard(email: String, onSignOut: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    val scope = rememberCoroutineScope()
    var section by remember { mutableStateOf("Enquiries") }
    var rows by remember { mutableStateOf<List<Pair<String, Map<String, Any>>>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    var editingId by remember { mutableStateOf<String?>(null) }
    var f1 by remember { mutableStateOf("") }
    var f2 by remember { mutableStateOf("") }
    var f3 by remember { mutableStateOf("") }

    fun load() {
        loading = true; error = ""
        scope.launch {
            try {
                val snap = db.collection(section.lowercase()).orderBy("createdAt", Query.Direction.DESCENDING).limit(100).get().await()
                rows = snap.documents.map { it.id to (it.data ?: emptyMap()) }
            } catch (_: Exception) {
                try {
                    val snap = db.collection(section.lowercase()).limit(100).get().await()
                    rows = snap.documents.map { it.id to (it.data ?: emptyMap()) }
                } catch (_: Exception) { error = "Could not load $section. Check Firebase setup and Firestore rules." }
            } finally { loading = false }
        }
    }
    LaunchedEffect(section) { load() }

    fun openNew() {
        editingId = null; f1 = ""; f2 = ""; f3 = ""; showEditor = true
    }
    fun saveRecord() {
        val collection = section.lowercase()
        val data: Map<String, Any> = when (section) {
            "Clients" -> mapOf("name" to f1.trim(), "phone" to f2.trim(), "email" to f3.trim(), "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())
            "Orders" -> mapOf("clientName" to f1.trim(), "service" to f2.trim(), "status" to f3.trim(), "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())
            "Packages" -> mapOf("name" to f1.trim(), "price" to f2.trim(), "features" to f3.trim(), "active" to true, "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())
            else -> emptyMap()
        }
        scope.launch {
            try {
                if (editingId == null) db.collection(collection).add(data).await()
                else db.collection(collection).document(editingId!!).update(data - "createdAt").await()
                showEditor = false; notice = "$section saved successfully."; load()
            } catch (_: Exception) { error = "Save failed. Check your admin access and connection." }
        }
    }
    fun removeRecord(id: String) {
        scope.launch {
            try { db.collection(section.lowercase()).document(id).delete().await(); notice = "Record deleted."; load() }
            catch (_: Exception) { error = "Delete failed. Check your admin access." }
        }
    }

    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("Business Admin Panel") }
        item { Text("Secure session: $email", color = Muted, fontSize = 12.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Enquiries", "Clients", "Orders", "Packages").forEach { name ->
                    FilterChip(selected = section == name, onClick = { section = name }, label = { Text(name) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = Ink))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { load() }) { Text("Refresh", color = Gold) }
                if (section != "Enquiries") Button(onClick = { openNew() }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Icon(Icons.Default.Add, null); Text("Add") }
            }
        }
        if (notice.isNotBlank()) item { Text(notice, color = Gold) }
        if (error.isNotBlank()) item { Text(error, color = Color(0xFFFF8A80)) }
        if (loading) item { CircularProgressIndicator(color = Gold) }
        if (!loading && rows.isEmpty()) item { Text("No ${section.lowercase()} found yet.", color = Muted) }
        items(rows, key = { it.first }) { (id, data) ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    when (section) {
                        "Enquiries" -> {
                            Text(data["name"]?.toString() ?: "Customer", color = Gold, fontWeight = FontWeight.Bold)
                            Text(data["phone"]?.toString() ?: "", color = Color.White)
                            Text(data["message"]?.toString() ?: "", color = Muted)
                            Text("Status: ${data["status"] ?: "new"}", color = Muted, fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { scope.launch { try { db.collection("enquiries").document(id).update("status", "contacted").await(); load() } catch (_: Exception) { error = "Status update failed." } } }) { Text("Mark contacted", color = Gold) }
                                OutlinedButton(onClick = { removeRecord(id) }) { Text("Delete", color = Color(0xFFFF8A80)) }
                            }
                        }
                        "Clients" -> {
                            Text(data["name"]?.toString() ?: "Client", color = Gold, fontWeight = FontWeight.Bold)
                            Text(data["phone"]?.toString() ?: "", color = Color.White); Text(data["email"]?.toString() ?: "", color = Muted)
                        }
                        "Orders" -> {
                            Text(data["clientName"]?.toString() ?: "Order", color = Gold, fontWeight = FontWeight.Bold)
                            Text("Service: ${data["service"] ?: "-"}", color = Color.White); Text("Status: ${data["status"] ?: "-"}", color = Muted)
                        }
                        else -> {
                            Text(data["name"]?.toString() ?: "Package", color = Gold, fontWeight = FontWeight.Bold)
                            Text("Price: ${data["price"] ?: "Not set"}", color = Color.White); Text(data["features"]?.toString() ?: "", color = Muted)
                        }
                    }
                    if (section != "Enquiries") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { editingId = id; f1 = when(section) { "Clients" -> data["name"]?.toString().orEmpty(); "Orders" -> data["clientName"]?.toString().orEmpty(); else -> data["name"]?.toString().orEmpty() }; f2 = when(section) { "Clients" -> data["phone"]?.toString().orEmpty(); "Orders" -> data["service"]?.toString().orEmpty(); else -> data["price"]?.toString().orEmpty() }; f3 = when(section) { "Clients" -> data["email"]?.toString().orEmpty(); "Orders" -> data["status"]?.toString().orEmpty(); else -> data["features"]?.toString().orEmpty() }; showEditor = true }) { Text("Edit", color = Gold) }
                        OutlinedButton(onClick = { removeRecord(id) }) { Text("Delete", color = Color(0xFFFF8A80)) }
                    }
                }
            }
        }
        item { OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) { Text("Sign Out", color = Gold) } }
    }
    if (showEditor) {
        val labels = when(section) { "Clients" -> listOf("Client name", "Phone", "Email"); "Orders" -> listOf("Client name", "Service", "Status"); else -> listOf("Package name", "Price (₹)", "Features / inclusions") }
        AlertDialog(onDismissRequest = { showEditor = false }, containerColor = Panel,
            title = { Text(if (editingId == null) "Add $section" else "Edit $section", color = Gold) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(f1, { f1 = it }, label = { Text(labels[0]) }, singleLine = true)
                OutlinedTextField(f2, { f2 = it }, label = { Text(labels[1]) }, singleLine = true)
                OutlinedTextField(f3, { f3 = it }, label = { Text(labels[2]) }, minLines = 2)
            } },
            confirmButton = { TextButton(onClick = { if (f1.isBlank() || f2.isBlank()) error = "Please fill the required fields." else saveRecord() }) { Text("Save", color = Gold) } },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text("Cancel", color = Muted) } }
        )
    }
}

@Composable
private fun ContactCard() {
    val context = LocalContext.current
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("CONTACT VELMORA", color = Gold, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            ContactLine(Icons.Default.Phone, "7877561704") {
                context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:7877561704")))
            }
            ContactLine(Icons.Default.Email, "velmoraeccom@gmail.com") {
                context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:velmoraeccom@gmail.com")))
            }
            ContactLine(Icons.Default.LocationOn, "Jaipur, Rajasthan")
        }
    }
}

@Composable
private fun ContactLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, action: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().then(if (action != null) Modifier.clickable { action() } else Modifier),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, tint = Gold, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, color = Color.White)
    }
}

@Composable private fun SectionTitle(title: String) {
    Text(title, color = Gold, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
}

@Composable private fun GoldButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
        shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Text(text, fontWeight = FontWeight.Bold)
    }
}
